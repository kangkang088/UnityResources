using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu()]
public class ItemDBSO : ScriptableObject
{

    public List<ItemSO> itemList;

}
