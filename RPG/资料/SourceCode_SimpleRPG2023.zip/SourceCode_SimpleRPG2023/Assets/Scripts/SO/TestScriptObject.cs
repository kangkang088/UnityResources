using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu()]
public class TestScriptObject : ScriptableObject
{
    public int age;
    //public string name;
    public string[] list;
}
